package com.company;

import org.graalvm.compiler.core.common.type.ArithmeticOpTable;

public class Main {

    public static void main(String[] args) {
	ShopOfChocolate chocolateSnickers=new ShopOfChocolate("snickers",250);
	ShopOfChocolate chocolateMars=new ShopOfChocolate("mars",190);
	ShopOfChocolate chocolateTwix=new ShopOfChocolate("twix",210);
	ListOfChocolate list=new ListOfChocolate();
	list.add(chocolateSnickers);
	list.add(chocolateMars);
	list.add(chocolateTwix);
	list.printAllProducts();
    }
}
