package com.company;

import lesson.AbstractProduct;
import lesson.AbstractShop;

public class ShopOfChocolate extends AbstractProduct {
    public ShopOfChocolate(String name, double price) {
        super(name, price);
    }
}
