package com.company;

import lesson.AbstractShop;

public class ListOfChocolate extends AbstractShop {

}
